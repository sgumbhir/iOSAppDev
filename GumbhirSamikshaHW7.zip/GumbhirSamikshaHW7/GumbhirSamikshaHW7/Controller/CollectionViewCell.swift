//
//  CollectionViewCell.swift
//  GumbhirSamikshaHW7
//
//  Created by Samiksha Gumbhir on 11/6/22.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewCell: UIImageView!
    
    
}
